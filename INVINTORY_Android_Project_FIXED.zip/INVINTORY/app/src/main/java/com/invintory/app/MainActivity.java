package com.invintory.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int ORANGE = Color.rgb(244,123,32), DARK = Color.rgb(45,45,45), BG = Color.rgb(255,248,242);
    private LinearLayout root, content;
    private SharedPreferences prefs;
    private String currentSection = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("invintory_data", MODE_PRIVATE);
        showHome();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setBackground(shape(ORANGE, 22)); b.setPadding(22, 8, 22, 8); return b;
    }
    private void base(String title, boolean home) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        setContentView(root);
        LinearLayout header = new LinearLayout(this); header.setOrientation(LinearLayout.VERTICAL); header.setPadding(22, 24, 22, 20); header.setBackground(shape(ORANGE, 0));
        if (!home) { TextView back = text("‹  الرئيسية", 16, Color.WHITE, true); back.setPadding(0,0,0,8); back.setOnClickListener(v -> showHome()); header.addView(back); }
        TextView brand = text("INVINTORY", 27, Color.WHITE, true); header.addView(brand);
        header.addView(text(title, 14, Color.WHITE, false)); root.addView(header);
        ScrollView scroll = new ScrollView(this); content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(18, 18, 18, 26); scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(text("  INVINTORY  •  إدارة المحتوى والحضور", 11, Color.GRAY, false));
    }
    private void showHome() {
        base("إدارة المحتوى والحضور بسهولة", true);
        content.addView(text("أهلاً بيك 👋", 22, DARK, true));
        TextView hint = text("اختار القسم اللي عاوز تفتحه", 15, Color.GRAY, false); content.addView(hint);
        addSpace(content, 12);
        card("🎬", "فيديو تعليمي", "إضافة عناوين وروابط الفيديوهات", "فيديو تعليمي");
        card("🖼️", "الصور", "إضافة وصف أو رابط للصورة", "الصور");
        card("🔔", "التنبيهات", "إضافة تنبيه مع التاريخ والوقت", "التنبيهات");
        card("📋", "تسجيل حضور", "تسجيل حضور وانصراف الموظفين", "تسجيل حضور");
        addSpace(content, 10);
        content.addView(text("البيانات محفوظة على هذا الجهاز.", 12, Color.GRAY, false));
    }
    private void card(String icon, String title, String subtitle, String section) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(18, 16, 18, 16); box.setBackground(shape(Color.WHITE, 24));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 12; box.setElevation(2); content.addView(box, lp);
        box.addView(text(icon + "   " + title, 19, ORANGE, true)); box.addView(text(subtitle, 13, Color.GRAY, false));
        box.setOnClickListener(v -> showSection(section));
    }
    private void addSpace(LinearLayout layout, int dp) { View v = new View(this); layout.addView(v, new LinearLayout.LayoutParams(1, dp)); }
    private String key(String section) { return "items_" + section; }
    private JSONArray read(String section) { try { return new JSONArray(prefs.getString(key(section), "[]")); } catch(Exception e) { return new JSONArray(); } }
    private void save(String section, JSONArray arr) { prefs.edit().putString(key(section), arr.toString()).apply(); }

    private void showSection(String section) {
        currentSection = section; base(section, false);
        if (section.equals("تسجيل حضور")) {
            Button attend = button("＋ تسجيل حضور الآن"); content.addView(attend); attend.setOnClickListener(v -> attendanceDialog("حضور"));
            Button leave = button("＋ تسجيل انصراف الآن"); LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1,-2); blp.topMargin=8; content.addView(leave, blp); leave.setOnClickListener(v -> attendanceDialog("انصراف"));
        } else {
            Button add = button("＋ إضافة جديد"); content.addView(add); add.setOnClickListener(v -> addDialog(section));
        }
        addSpace(content, 18); content.addView(text("السجلات", 19, DARK, true)); addSpace(content, 8);
        renderItems(section);
    }
    private void addDialog(String section) {
        LinearLayout form = new LinearLayout(this); form.setPadding(8, 4, 8, 4); form.setOrientation(LinearLayout.VERTICAL);
        EditText title = new EditText(this); title.setHint(section.equals("التنبيهات") ? "عنوان التنبيه" : "العنوان"); form.addView(title);
        EditText detail = new EditText(this); detail.setHint(section.equals("فيديو تعليمي") ? "رابط الفيديو أو وصفه" : section.equals("الصور") ? "رابط الصورة أو وصفها" : "تفاصيل التنبيه"); form.addView(detail);
        new AlertDialog.Builder(this).setTitle("إضافة إلى " + section).setView(form)
          .setNegativeButton("إلغاء", null).setPositiveButton("حفظ", (d,w) -> {
            String a = title.getText().toString().trim(), b = detail.getText().toString().trim();
            if (a.isEmpty()) { Toast.makeText(this, "اكتب العنوان أولاً", Toast.LENGTH_SHORT).show(); return; }
            JSONObject obj = new JSONObject(); try { obj.put("title", a); obj.put("detail", b); obj.put("time", now()); } catch(Exception ignored) {}
            JSONArray arr = read(section); arr.put(obj); save(section, arr); showSection(section);
          }).show();
    }
    private void attendanceDialog(String type) {
        EditText name = new EditText(this); name.setHint("اسم الموظف"); name.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        new AlertDialog.Builder(this).setTitle("تسجيل " + type).setView(name).setNegativeButton("إلغاء", null).setPositiveButton("تسجيل", (d,w) -> {
            String n = name.getText().toString().trim(); if (n.isEmpty()) { Toast.makeText(this,"اكتب اسم الموظف",Toast.LENGTH_SHORT).show(); return; }
            JSONObject obj = new JSONObject(); try { obj.put("title", n); obj.put("detail", type); obj.put("time", now()); } catch(Exception ignored) {}
            JSONArray arr = read("تسجيل حضور"); arr.put(obj); save("تسجيل حضور", arr); showSection("تسجيل حضور");
        }).show();
    }
    private String now() { return new SimpleDateFormat("yyyy/MM/dd  hh:mm a", Locale.getDefault()).format(new Date()); }
    private void renderItems(String section) {
        JSONArray arr = read(section);
        if (arr.length() == 0) { TextView empty = text("لا توجد سجلات حتى الآن. اضغط على زر الإضافة للبدء.", 14, Color.GRAY, false); empty.setPadding(4,12,4,12); content.addView(empty); return; }
        for (int i = arr.length()-1; i >= 0; i--) {
            JSONObject o = arr.optJSONObject(i); if (o == null) continue;
            final int index = i;
            LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setPadding(15,13,15,13); row.setBackground(shape(Color.WHITE,18));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=9; content.addView(row,lp);
            row.addView(text(o.optString("title"), 17, DARK, true));
            if (!o.optString("detail").isEmpty()) row.addView(text(o.optString("detail"), 14, ORANGE, false));
            row.addView(text(o.optString("time"), 11, Color.GRAY, false));
            Button del = button("حذف"); LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-2,-2); dp.topMargin=6; row.addView(del,dp);
            del.setOnClickListener(v -> new AlertDialog.Builder(this).setMessage("متأكد إنك عاوز تحذف السجل؟").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(dialog,which)->{ JSONArray updated=read(section); JSONArray out=new JSONArray(); for(int j=0;j<updated.length();j++) if(j!=index) out.put(updated.optJSONObject(j)); save(section,out); showSection(section); }).show());
        }
    }
}
